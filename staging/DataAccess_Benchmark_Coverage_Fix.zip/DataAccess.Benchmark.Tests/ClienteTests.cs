using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataAccess.Benchmark.Tests;

[TestClass]
public class ClienteTests
{
    [TestMethod]
    public void Properties_RoundTrip_AllValues()
    {
        var created = new DateTime(2026, 8, 25, 0, 0, 0, DateTimeKind.Utc);

        var cliente = new Cliente
        {
            Id = 42,
            Name = "Coverage Test",
            Mail = "coverage@example.invalid",
            CreateAt = created,
            Activated = true
        };

        Assert.AreEqual(42, cliente.Id);
        Assert.AreEqual("Coverage Test", cliente.Name);
        Assert.AreEqual("coverage@example.invalid", cliente.Mail);
        Assert.AreEqual(created, cliente.CreateAt);
        Assert.IsTrue(cliente.Activated);
    }
}
